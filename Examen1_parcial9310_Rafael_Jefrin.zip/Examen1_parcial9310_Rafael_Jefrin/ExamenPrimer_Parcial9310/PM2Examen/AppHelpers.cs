﻿using PM2Examen.Controllers;
using System;

namespace PM2Examen
{
    internal static class AppHelpers
    {

        
       
    }
}